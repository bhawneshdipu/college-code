#include <bits/stdc++.h>
using namespace std;

typedef long long LL;

#define PII       pair<int,int>
#define all(c)    c.begin(),c.end()
#define sz(c)     (int)c.size()
#define clr(c)    c.clear()
#define pb        push_back
#define mp        make_pair
#define cin(x)    scanf("%d",&x)
#define MOD		1000000007
#define EPS		1E-10

int cnt[1000000] = {0};
int A[1000000] = {0};
int B[1000000] = {0};

int modA[1000000] = {0};
int modB[1000000] = {0};

int BigMod(int a, int b, int mod)
{
    if(b == 0) return 1;
    LL x = BigMod(a,b/2,mod);
    x = (x * x) % mod;
    if(b&1)
    x = (x * a) % mod;
    return (int)x;
}

int add(int a,int b,int c = MOD)
{
    a += b;
    while(a >= c) a -= c;
    return a;
}
int cas=0;
void solve()
{
    int a,b,k;
    LL n;
    cin >> a >> b >> n >> k;
    
    memset(cnt,0,sizeof(cnt));
    memset(A,0,sizeof(A));
    memset(B,0,sizeof(B));
    memset(modA,0,sizeof(modA));
    memset(modB,0,sizeof(modB));
    
    for(int i = 1; i <= k; i++)
    cnt[i%k] = ((n / k) % MOD);
    n %= k;
    for(int i = 1; i <= n; i++)
    cnt[i]++;
    
    LL remove = 0, total = 0;
    
    for(int i = 0; i < k; i++)
    {
        A[i] = BigMod(i,a,k)%k;
        B[i] = BigMod(i,b,k)%k;
        modA[A[i]] = add(modA[A[i]], cnt[i]);
        modB[B[i]] = add(modB[B[i]], cnt[i]);
        if((A[i] + B[i]) % k == 0)
        remove = add(remove, cnt[i]);
    }
    for(int i = 0; i < k; i++)
    {
        int m1 = i;
        int m2 = (k - i) % k;
        total += ((1LL * modA[m1] * modB[m2]) % MOD);
        total %= MOD;
    }
    total -= remove;
    if(total < 0)
    total += MOD;
    cas++;
    cout<<"Case #"<<cas<<": ";
    cout << total << "\n";
}

int main()
{
    freopen("s1.txt","r",stdin);
    freopen("n21.txt", "w", stdout);
    int t;
    cin >> t;
    while(t--)
    solve();
    return 0;
}