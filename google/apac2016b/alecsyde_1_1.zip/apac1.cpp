#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define pii pair<int,int>
#define pll pair<ll,ll>
#define pdd pair<double,double>
#define X first
#define Y second
#define REP(i,a) for(int i=0;i<a;++i)
#define REPP(i,a,b) for(int i=a;i<b;++i)
#define FILL(a,x) memset(a,x,sizeof(a))
#define	foreach( gg,itit )	for( typeof(gg.begin()) itit=gg.begin();itit!=gg.end();itit++ )
#define	mp make_pair
#define	pb push_back
#define all(s) s.begin(),s.end()
#define present(c,x) ((c).find(x) != (c).end())
const double EPS = 1e-8;
const int mod = 1e9+7;
const int N = 1e6+10;
const ll INF = 1e18;

//#define DEBUG
ll power(ll x,ll y,ll mod){
  ll t=1;
  while(y>0){
    if(y%2) y-=1,t=t*x%mod;
    else y/=2,x=x*x%mod;
  }
  return t%mod;
}
#ifdef DEBUG
#define dprintf(fmt,...) fprintf(stderr,fmt,__VA_ARGS__)
#else
#define dprintf(fmt,...)
#endif

ll cta[N],cot[N];
ll ctb[N],rv[N];
int main(){
	int q; scanf("%d",&q);
	REP(aa,q){
		ll a,b,n,k;
		scanf("%lld%lld%lld%lld",&a,&b,&n,&k);
	//	a=b=1000000,n=INF,k=100000;
		REP(i,k) rv[i]=0;
		REP(i,k){
			cot[i]=(n/k+(n%k>=i))%mod;
			if(i==0) cot[i]--;
			cta[i]=power(i,a,k);
			ctb[i]=power(i,b,k);
			rv[ctb[i]]=(rv[ctb[i]]+cot[i])%mod;
		}
		ll sum=0;
		REP(i,k){
			sum=(sum+cot[i]*rv[(k-cta[i])%k]%mod)%mod;
			if((cta[i]+ctb[i])%k==0){
				sum=(sum-cot[i])%mod;
			}
		}
		sum=(sum%mod+mod)%mod;
		printf("Case #%d: %lld\n",aa+1,sum);
	}
	return 0;
}
