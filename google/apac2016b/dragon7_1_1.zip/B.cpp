#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef vector<int> vi;
typedef pair<int,int> pii;
const int MAXK = 100010;
ll mp = 1000000007;
ll ix[MAXK], jx[MAXK],cnt[MAXK];
// i ^a % k
ll fexp(ll i, ll a, ll k)
{
	if(a==0)return 1%k;
	if(a==1)return i;
	ll w = fexp(i,a/2,k);
	w = w*w%k;
	if(a&1)w=w*i%k;
	return w;
}
int main()
{
	int test;
	cin>>test;
	for(int z=1;z<=test;z++)
	{
		ll a,b,n,k;
		cin>>a>>b>>n>>k;
		for(int i=0;i<k;i++)
		{
			ix[i]=jx[i]=cnt[i]=0;
		}
		for(int i=0;i<k;i++)
		{
			cnt[i] = n/k;
		}
		ll nn = n - n%k;
		for(ll i=nn+1; i<=n;i++)
		{
			cnt[i%k]++;
		}
		for(int i=0;i<k;i++)
			cnt[i]%=mp;
		for(int i=0;i<k;i++)
		{
			ix[fexp(i,a,k)]+=cnt[i];
			jx[fexp(i,b,k)]+=cnt[i];
		}
		for(int i=0;i<k;i++)
		{
			ix[i]%=mp;
			jx[i]%=mp;
		}
//		for(int i=0;i<k;i++)
//		{
//			cout<<cnt[i]<<" "<<ix[i]<<" "<<jx[i]<<endl;
//		}
		ll ans = 0;
		for(int i=0;i<k;i++)
		{
			ans += (ix[i]*jx[(k-i)%k]);
			ans %= mp;
		}
		// subtract i=j case
		for(int i=0;i<k;i++)
		{
			ll res = (fexp(i,a,k)+fexp(i,b,k))%k;
			if(res==0)ans-=cnt[i];
			ans%=mp;
		}
		ans %= mp;
		ans += mp;
		ans %= mp;
		cout<<"Case #"<<z<<": "<<ans<<endl;
	}
}
